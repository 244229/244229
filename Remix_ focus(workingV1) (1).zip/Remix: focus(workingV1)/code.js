// Declaring Global Variables 

//Declare -wordList- and -answerList- 

// Data is from the SCRABBLE DICTIONARY
var wordList=getColumn("wordList", "WORDS");

// Data is from Code.org Data Library; WORDLE
var answerList = getColumn("Wordle", "validWordleAnswer");

//Declare -wordGuess- and -wordGuessLetters- 
var wordGuess;
var wordGuessLetters = [];

//Declare -wordChosen- and -wordChosenLetters- 
var wordChosen;
var wordChosenLetters = [];

// Miscellaneous variables neccessary to the program 
var guessCounter = 0;
var wordFound = 0;
var colors = [];
var winCondition = "false";

// Basic buttons: (Start!) + (Try) + (New Word) 

// (Start!) - when clicked will send user to play screen 
onEvent("button(Start)", "click", function( ) {
  setScreen("screen(Play)");
  resetDisplay();
  wordChosenFunction();
});

// (Try) - when clicked gets the user input and updates it to wordGuess
//If user input is a valid guess it will compare wordGuess to wordChosen and display outputs on screen 
//If user input is not a valid guess, text on screen will display an error message
onEvent("button(Guess)", "click", function( ) {
  wordGuessFunction();
  if (wordFound==1) {
    color();
    setDisplay(guessCounter, wordGuessLetters, colors, winCondition);
  } else {
    showElement("invalidTextOutput");
  }
});

// (New Word) - when clicked generates a new correct answer -wordChosen- and resets display outputs 
onEvent("button(NewWord)", "click", function( ) {
  resetDisplay();
  wordChosenFunction();
});

// Function to choose a correct answer -wordChosen-
function wordChosenFunction() {
  // Generates a correct answer -wordChosen- 
  wordChosen = answerList[(randomNumber(0,2308))].toUpperCase();
}

// Function to get user input -wordGuess- and convert into letters -wordGuessLetters- 
function wordGuessFunction() {
  hideElement("invalidTextOutput");
  
  // Resets/updates variables 
  wordGuess = getText("guessInput").toUpperCase();
  wordGuessLetters = [];
  wordFound = 0;
  
  // This verifies if the user input is a valid attempt 
  for (var i = 0; wordFound==0 && i < wordList.length; i++) {
    if (wordList[i]==wordGuess) {
      
      wordFound=1;
      
      // Breaks up -wordGuess- into letters and puts it into -wordGuessLetters- 
      appendItem(wordGuessLetters, wordGuess.substring(0, 1));
      appendItem(wordGuessLetters, wordGuess.substring(1, 2));
      appendItem(wordGuessLetters, wordGuess.substring(2, 3));
      appendItem(wordGuessLetters, wordGuess.substring(3, 4));
      appendItem(wordGuessLetters, wordGuess.substring(4, 5));
      guessCounter = guessCounter + 1;
    }
  }
  setText("guessInput", "");
}

//
function color() {
  //Set up local and global variables
  var correctPos = [];
  var toCheck = [];
  
  colors = [];
  
  //resets wordChosenLetters
  breakWordChosen(wordChosen);
  
  // Checks to see if any letters in wordGuess are in the same position as the letters in wordChosen
  // If a letter is in the correct position "green" is added to the list -colors-
  // If a letter is in the wrong position "red" is added the the list -colors-
  for (var a = 0; a < 5; a++) {
    if (wordGuessLetters[a] === wordChosenLetters[a]) {
      appendItem(correctPos, wordGuessLetters[a]);
      appendItem(colors, "green");
      appendItem(toCheck, "-");
      wordChosenLetters[a] = "-";
    } else {
      appendItem(correctPos, "-");
      appendItem(toCheck, wordGuessLetters[a]);
      appendItem(colors, "red");
    }
  }
  
  // Checks to see if the letters in the wrong position are in wordChosen
  // If the letter is found in wordChosen then its color output is changed to "yellow"
  // If the letter is not found in wordChosen then its color output stays at "red"
  for (var b = 0; b < 5; b++) {
    if (toCheck[b] != "-" && wordChosenLetters.join().includes(toCheck[b])) {
      colors[b] = "yellow";
      wordChosenLetters[(wordChosenLetters.indexOf(toCheck[b]))] = "-";
    }
  }
  
  // Checks to see if wordGuess is correct
  if (colors[0] == "green" && colors[1] == "green" && colors[2] == "green" && colors[3] == "green" && colors[4] == "green" ) {
    winCondition = "true";
  }
}

//Function to break up wordChosen into wordChosenLetters 
function breakWordChosen(wordChosen) {
  wordChosenLetters = [];
  appendItem(wordChosenLetters, wordChosen.substring(0, 1));
  appendItem(wordChosenLetters, wordChosen.substring(1, 2));
  appendItem(wordChosenLetters, wordChosen.substring(2, 3));
  appendItem(wordChosenLetters, wordChosen.substring(3, 4));
  appendItem(wordChosenLetters, wordChosen.substring(4, 5));
}

// Function to display wordGuessLetters on screen
//Also displays labels/text based on whether or not the game has been won or lost
// Conditions for a win is if the user correctly guesses the wordChosen in six attempts or less
// Conditions for a loss is if the user fails to guess the wordChosen in six attempts or less 
function setDisplay(attempt, inputletters, colorlist, winStatus) {
  // Displays wordGuessLetters and colors on screen
  if (attempt < 7) {
    setText("guessCounterOutput", attempt);
    for (var i = 0; i < 5; i++) {
      setText(("output" + guessCounter) + i, inputletters[i]);
      setProperty("output" + guessCounter + i, "border-color", colorlist[i]);
      setProperty(("output" + guessCounter) + i, "text-color", colorlist[i]);
    }
  } else {
    setText("guessCounterOutput", 6);
  }
  
  // Sets display output based on whether the game has been won or lost
  if (attempt == 6 && winStatus == "false" ) {
    hideElement("guessInput");
    hideElement("button(Guess)");
    showElement("answerOutput");
    showElement("lossOutput");
    setText("answerOutput", wordChosen);
    setProperty("button(NewWord)", "border-color", "white");
    setProperty("button(NewWord)", "text-color", "white");
  } else if (attempt <= 6 && winStatus == "true") {
    hideElement("guessInput");
    hideElement("button(Guess)");
    showElement("answerOutput");
    showElement("winOutput");
    setText("answerOutput", wordChosen);
    setProperty("button(NewWord)", "border-color", "white");
    setProperty("button(NewWord)", "text-color", "white");
  }
}

// Resets the display outputs for a new game 
function resetDisplay() {
  // Reset variables
  guessCounter = 0;
  winCondition = "false";
  
  // Reset on screen outputs
  setProperty("button(NewWord)", "border-color", "blue");
  setProperty("button(NewWord)", "text-color", "blue");
  setText("guessCounterOutput", guessCounter);
  hideElement("answerOutput");
  hideElement("winOutput");
  hideElement("lossOutput");
  hideElement("invalidTextOutput");
  showElement("guessInput");
  showElement("button(Guess)");
  
  for (var row = 1; row < 7; row++) {
    for (var column = 0; column < 5; column++) {
      setProperty("output" + row + column, "border-color", "grey");
      setProperty(("output" + row) + column, "text-color", "grey");
      setProperty("output" + row + column, "text", "");
      setProperty("output" + row + column, "text", "");
    }
  }
}
